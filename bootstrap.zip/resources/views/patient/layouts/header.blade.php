<header class="bg-white shadow-md fixed top-0 left-0 w-full md:pl-64 h-16 z-50">
    <div class="max-w-7xl mx-auto px-4 flex items-center justify-between h-full">
        <h1 class="text-lg font-bold text-blue-700">Patient Dashboard</h1>
        <button onclick="togglePatientSidebar()" class="md:hidden text-blue-700 text-2xl">
            ☰
        </button>
    </div>
    
</header>