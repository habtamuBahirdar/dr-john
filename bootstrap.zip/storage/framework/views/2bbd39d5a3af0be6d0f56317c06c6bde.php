

<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold mb-4">Manage Users</h1>

    <a href="<?php echo e(route('users.create')); ?>"
        class="mb-4 inline-block bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
        + Add User
    </a>

    <form method="GET" action="<?php echo e(route('users.index')); ?>" class="mb-4 flex flex-wrap gap-2 items-end">
        <div>
            <label for="usertype" class="block text-sm font-medium">User Type</label>
            <select name="usertype" id="usertype" class="border rounded px-2 py-1">
                <option value="">All</option>
                <option value="patient" <?php echo e(request('usertype') == 'patient' ? 'selected' : ''); ?>>Patient</option>
                <option value="doctor" <?php echo e(request('usertype') == 'doctor' ? 'selected' : ''); ?>>Doctor</option>
                <option value="scheduler" <?php echo e(request('usertype') == 'scheduler' ? 'selected' : ''); ?>>Scheduler</option>
                <option value="admin" <?php echo e(request('usertype') == 'admin' ? 'selected' : ''); ?>>Admin</option>
            </select>
        </div>
        <div>
            <label for="sort" class="block text-sm font-medium">Sort By</label>
            <select name="sort" id="sort" class="border rounded px-2 py-1">
                <option value="created_desc" <?php echo e(request('sort') == 'created_desc' ? 'selected' : ''); ?>>Newest</option>
                <option value="created_asc" <?php echo e(request('sort') == 'created_asc' ? 'selected' : ''); ?>>Oldest</option>
                <option value="alpha_asc" <?php echo e(request('sort') == 'alpha_asc' ? 'selected' : ''); ?>>A-Z</option>
                <option value="alpha_desc" <?php echo e(request('sort') == 'alpha_desc' ? 'selected' : ''); ?>>Z-A</option>
            </select>
        </div>
        <div>
            <label for="search" class="block text-sm font-medium">Search</label>
            <input type="text" name="search" id="search" value="<?php echo e(request('search')); ?>"
                class="border rounded px-2 py-1" placeholder="Name or Email">
        </div>
        <div>
            <label for="date_from" class="block text-sm font-medium">Registered From</label>
            <input type="date" name="date_from" id="date_from" value="<?php echo e(request('date_from')); ?>"
                class="border rounded px-2 py-1">
        </div>
        <div>
            <label for="date_to" class="block text-sm font-medium">Registered To</label>
            <input type="date" name="date_to" id="date_to" value="<?php echo e(request('date_to')); ?>"
                class="border rounded px-2 py-1">
        </div>
        <div>
            <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Filter</button>
        </div>
    </form>

    <table class="w-full bg-white shadow-md rounded">
        <thead>
            <tr class="bg-indigo-100">
                <th class="p-3">Name</th>
                <th>Email</th>
                <th>User Type</th>
                <th>Status</th>
                <th class="text-right">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-t">
                    <td class="p-3"><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e(ucfirst($user->usertype)); ?></td>
                    <td>
                        <form action="<?php echo e(route('users.toggle', $user)); ?>" method="POST">
                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                            <button class="text-sm <?php echo e($user->active ? 'text-green-600' : 'text-green-600'); ?>">
                                <?php echo e($user->active ? 'Active' : 'Active'); ?>

                            </button>
                        </form>
                    </td>
                    <td class="text-right space-x-2 p-3">
                        <a href="<?php echo e(route('users.edit', $user)); ?>" class="text-blue-600">Edit</a>
                        <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="text-red-600" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\dr-john\resources\views/admin/users/index.blade.php ENDPATH**/ ?>