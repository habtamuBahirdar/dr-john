<header class="bg-white shadow-md p-4 flex items-center justify-between md:justify-end md:ml-64">
    <div class="md:hidden">
        
        <button id="menuToggle" class="text-blue-700">
            ☰
        </button>
    </div>

    <div>
        <span class="font-semibold">Welcome, Admin</span>
    </div>
</header>
<?php /**PATH D:\project\starters\e-ticket\resources\views/layouts/header.blade.php ENDPATH**/ ?>