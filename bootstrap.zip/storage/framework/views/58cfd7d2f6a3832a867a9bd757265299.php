<div class="bg-blue-700 text-white w-64 p-4 space-y-6 hidden md:block">
    <h2 class="text-2xl font-bold mb-4">Clinic System</h2>

    <nav class="space-y-2">
        <a href="#" class="block py-2 px-4 rounded hover:bg-blue-600">Dashboard</a>
        <a href="#" class="block py-2 px-4 rounded hover:bg-blue-600">Schedule</a>
        <a href="#" class="block py-2 px-4 rounded hover:bg-blue-600">Patients</a>
        <a href="#" class="block py-2 px-4 rounded hover:bg-blue-600">Doctors</a>
        <a href="#" class="block py-2 px-4 rounded hover:bg-blue-600">Logout</a>
    </nav>
</div>
<?php /**PATH D:\project\starters\e-ticket\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>