

<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold mb-4">Edit User</h1>

<form action="<?php echo e(route('users.update', $user)); ?>" method="POST" class="space-y-4 bg-white p-6 rounded shadow-md">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div>
        <label>Name</label>
        <input type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" class="w-full border p-2 rounded">
    </div>
    <div>
        <label>Email</label>
        <input type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" class="w-full border p-2 rounded">
    </div>
    <div>
        <label>Password <small>(leave blank to keep current)</small></label>
        <input type="password" name="password" class="w-full border p-2 rounded">
    </div>
    <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Update</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\dr-john\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>