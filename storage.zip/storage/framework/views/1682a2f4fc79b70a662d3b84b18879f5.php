


<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto mt-10 bg-white p-8 rounded-lg shadow-md">
    <h1 class="text-2xl font-bold text-blue-700 mb-6">Appointment Details</h1>
    <p><strong>Date:</strong> <?php echo e($appointment->appointment_date); ?></p>
    <p><strong>Time:</strong> <?php echo e($appointment->appointment_time); ?></p>
    <p><strong>Type:</strong> <?php echo e(ucfirst($appointment->appointment_type)); ?></p>
    <p><strong>Status:</strong> <?php echo e(ucfirst($appointment->status)); ?></p>
    <a href="<?php echo e(route('appointments.index')); ?>" class="text-blue-500 hover:underline mt-4 inline-block">Back to Appointments</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('patient.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\My comany\dr-yohannes online schedule\dr-john\resources\views\patient\appointments\show.blade.php ENDPATH**/ ?>