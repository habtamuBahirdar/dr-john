


<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto bg-white p-6 rounded-lg shadow-md">
    <h1 class="text-2xl font-bold text-indigo-700 mb-6">Transactions</h1>

    
    <form method="GET" action="<?php echo e(route('transactions.index')); ?>" class="mb-6">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            
            <div>
                <label for="search" class="block text-gray-700 font-bold mb-2">Search</label>
                <input type="text" id="search" name="search" value="<?php echo e(request('search')); ?>"
                    class="w-full border-gray-300 rounded-lg shadow-sm focus:ring focus:ring-blue-200"
                    placeholder="Transaction Ref or ID">
            </div>

            
            <div>
                <label for="start_date" class="block text-gray-700 font-bold mb-2">Start Date</label>
                <input type="date" id="start_date" name="start_date" value="<?php echo e(request('start_date')); ?>"
                    class="w-full border-gray-300 rounded-lg shadow-sm focus:ring focus:ring-blue-200">
            </div>

            
            <div>
                <label for="end_date" class="block text-gray-700 font-bold mb-2">End Date</label>
                <input type="date" id="end_date" name="end_date" value="<?php echo e(request('end_date')); ?>"
                    class="w-full border-gray-300 rounded-lg shadow-sm focus:ring focus:ring-blue-200">
            </div>

            
            <div class="flex items-end">
                <button type="submit"
                    class="bg-indigo-700 text-white px-6 py-2 rounded-lg hover:bg-indigo-600 w-full">
                    Filter
                </button>
            </div>
        </div>
    </form>

    
    <div class="mb-6">
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg">
            <p class="font-bold">Total Amount:</p>
            <p class="text-lg"><?php echo e(number_format($totalAmount, 2)); ?> <?php echo e($transactions->first()->currency ?? 'USD'); ?></p>
        </div>
    </div>

    
    <table class="w-full border-collapse border border-gray-300">
        <thead>
            <tr class="bg-indigo-700 text-white">
                <th class="border border-gray-300 px-4 py-2">#</th>
                <th class="border border-gray-300 px-4 py-2">Transaction Reference</th>
                <th class="border border-gray-300 px-4 py-2">Patient</th>
                <th class="border border-gray-300 px-4 py-2">Amount</th>
                <th class="border border-gray-300 px-4 py-2">Status</th>
                <th class="border border-gray-300 px-4 py-2">Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="text-center">
                    <td class="border border-gray-300 px-4 py-2"><?php echo e($loop->iteration); ?></td>
                    <td class="border border-gray-300 px-4 py-2"><?php echo e($transaction->tx_ref); ?></td>
                    <td class="border border-gray-300 px-4 py-2">
                        <?php echo e($transaction->appointment->patient->name ?? 'N/A'); ?>

                    </td>
                    <td class="border border-gray-300 px-4 py-2"><?php echo e($transaction->amount); ?> <?php echo e($transaction->currency); ?></td>
                    <td class="border border-gray-300 px-4 py-2">
                        <span class="px-2 py-1 rounded-lg <?php echo e($transaction->status === 'paid' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'); ?>">
                            <?php echo e(ucfirst($transaction->status)); ?>

                        </span>
                    </td>
                    <td class="border border-gray-300 px-4 py-2"><?php echo e($transaction->created_at->format('Y-m-d H:i')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="border border-gray-300 px-4 py-2 text-center">No transactions found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="mt-4">
        <?php echo e($transactions->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\My comany\dr-yohannes online schedule\dr-john\resources\views\admin\transactions\index.blade.php ENDPATH**/ ?>