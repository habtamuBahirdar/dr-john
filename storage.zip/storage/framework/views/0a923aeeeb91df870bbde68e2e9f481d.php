


<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto mt-10 bg-white p-8 rounded-lg shadow-md">
    <h1 class="text-2xl font-bold text-green-700 mb-6">All Schedules</h1>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 p-3 rounded-md shadow-sm mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($schedules->isEmpty()): ?>
        <p class="text-gray-700">No schedules available.</p>
    <?php else: ?>
        <table class="w-full border-collapse border border-gray-300">
            <thead>
                <tr class="bg-gray-100">
                    <th class="border border-gray-300 px-4 py-2 text-left">Date</th>
                    <th class="border border-gray-300 px-4 py-2 text-left">Session</th>
                    <th class="border border-gray-300 px-4 py-2 text-left">Time</th>
                    <th class="border border-gray-300 px-4 py-2 text-left">Max Patients</th>
                    <th class="border border-gray-300 px-4 py-2 text-left">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="border border-gray-300 px-4 py-2"><?php echo e($schedule->date); ?></td>
                        <td class="border border-gray-300 px-4 py-2 capitalize"><?php echo e($schedule->session); ?></td>
                        <td class="border border-gray-300 px-4 py-2"><?php echo e($schedule->start_time); ?> - <?php echo e($schedule->end_time); ?></td>
                        <td class="border border-gray-300 px-4 py-2"><?php echo e($schedule->max_patients); ?></td>
                        <td class="border border-gray-300 px-4 py-2 flex space-x-2">
                            
                            <a href="<?php echo e(route('schedules.edit', $schedule->id)); ?>" class="text-blue-500 hover:underline">
                                Edit
                            </a>

                            
                            <form action="<?php echo e(route('schedules.destroy', $schedule->id)); ?>" method="POST" class="inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-500 hover:underline">
                                    Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('scheduler.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\My comany\dr-yohannes online schedule\dr-john\resources\views\scheduler\schedules\index.blade.php ENDPATH**/ ?>