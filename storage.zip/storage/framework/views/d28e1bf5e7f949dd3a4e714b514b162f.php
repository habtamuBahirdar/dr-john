


<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold mb-4">Edit Blog</h1>
    <?php if(session('success')): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

    <form action="<?php echo e(route('blogs.update', $blog)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-4">
            <label for="title" class="block text-gray-700 font-bold">Title</label>
            <textarea name="title" id="title" class="w-full border-gray-300 rounded-lg" required><?php echo e($blog->title); ?></textarea>
        </div>

        <div class="mb-4">
            <label for="content" class="block text-gray-700 font-bold">Content</label>
            <textarea name="content" id="content" rows="5" class="w-full border-gray-300 rounded-lg" required><?php echo e($blog->content); ?></textarea>
        </div>

        <div class="mb-4">
            <label for="images" class="block text-gray-700 font-bold">Images (up to 5)</label>
            <input type="file" name="images[]" id="images" multiple class="w-full border-gray-300 rounded-lg">
            <p class="text-sm text-gray-500 mt-1">You can upload up to 5 images. Each image must be less than 2MB.</p>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                <?php for($i = 1; $i <= 5; $i++): ?>
                    <?php if($blog->{'image_' . $i}): ?>
                        <div class="relative">
                            <img src="<?php echo e(asset('storage/' . $blog->{'image_' . $i})); ?>" alt="Blog Image <?php echo e($i); ?>" class="w-full h-40 object-cover rounded-lg">
                            <form action="<?php echo e(route('blogs.deleteImage', [$blog, $i])); ?>" method="POST" class="absolute top-2 right-2">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="bg-red-500 text-white p-1 rounded-full">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>
                <?php endfor; ?>
            </div>
        </div>

        <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Update Blog</button>
    </form>

    
    <script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
    <script>
        ClassicEditor
            .create(document.querySelector('#title'))
            .catch(error => {
                console.error(error);
            });

        ClassicEditor
            .create(document.querySelector('#content'))
            .catch(error => {
                console.error(error);
            });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\My comany\dr-yohannes online schedule\dr-john\resources\views\blogs\edit.blade.php ENDPATH**/ ?>