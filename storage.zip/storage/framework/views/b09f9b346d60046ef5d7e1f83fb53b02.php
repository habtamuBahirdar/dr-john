


<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto mt-10 bg-white p-8 rounded-lg shadow-md">
    <h1 class="text-2xl font-bold text-blue-700 mb-6">My Appointments</h1>

    <?php if($appointments->isEmpty()): ?>
        <p class="text-gray-700">You have no appointments yet.</p>
    <?php else: ?>

         <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 p-3 rounded-md shadow-sm mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
        <table class="w-full border-collapse border border-gray-300">
            <thead>
                <tr class="bg-gray-100">
                    <th class="border border-gray-300 px-4 py-2 text-left">Date</th>
                    <th class="border border-gray-300 px-4 py-2 text-left">Time</th>
                    <th class="border border-gray-300 px-4 py-2 text-left">Type</th>
                    <th class="border border-gray-300 px-4 py-2 text-left">Status</th>
                    <th class="border border-gray-300 px-4 py-2 text-left">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="border border-gray-300 px-4 py-2"><?php echo e($appointment->appointment_date); ?></td>
                        <td class="border border-gray-300 px-4 py-2"><?php echo e($appointment->appointment_time); ?></td>
                        <td class="border border-gray-300 px-4 py-2 capitalize"><?php echo e($appointment->appointment_type); ?></td>
                        <td class="border border-gray-300 px-4 py-2 capitalize"><?php echo e($appointment->status); ?></td>
                        <td class="border border-gray-300 px-4 py-2 flex space-x-2">
                            
                            <a href="<?php echo e(route('appointments.show', $appointment->id)); ?>" class="text-blue-500 hover:text-blue-700">
                                <i class="fas fa-eye"></i>
                            </a>

                            
                            <?php if($appointment->status === 'confirmed'): ?>
                                <a href="<?php echo e(route('appointments.edit', $appointment->id)); ?>" class="text-green-500 hover:text-green-700">
                                    <i class="fas fa-edit"></i>
                                </a>
                            <?php endif; ?>

                            
                            <?php if($appointment->status === 'pending'): ?>
                                <form action="<?php echo e(route('appointments.destroy', $appointment->id)); ?>" method="POST" class="inline-block">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-500 hover:text-red-700">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('patient.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\My comany\dr-yohannes online schedule\dr-john\resources\views\patient\appointments\index.blade.php ENDPATH**/ ?>