

<?php $__env->startSection('content'); ?>
<div class="container mx-auto py-8">
    <h1 class="text-2xl font-bold mb-6">Shift Appointment</h1>

    <?php if(session('success')): ?>
        <div class="bg-green-500 text-white p-4 mb-4 rounded">
            <?php echo e(session('success')); ?>

        </div>
    <?php elseif(session('error')): ?>
        <div class="bg-red-500 text-white p-4 mb-4 rounded">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <div class="space-y-6">
        <!-- List of Appointments -->
        <h2 class="text-xl font-semibold mb-4">Appointments to Shift</h2>
        <table class="table-auto w-full border border-gray-300">
            <thead>
                <tr>
                    <th class="px-4 py-2 text-left">Patient Name</th>
                    <th class="px-4 py-2 text-left">Appointment Date</th>
                    <th class="px-4 py-2 text-left">Appointment Time</th>
                    <th class="px-4 py-2 text-left">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-4 py-2"><?php echo e($appointment->patient->name); ?></td>
                        <td class="px-4 py-2"><?php echo e($appointment->appointment_date); ?></td>
                        <td class="px-4 py-2"><?php echo e($appointment->appointment_time); ?></td>
                        <td class="px-4 py-2">
                            <!-- Shift Appointment Form -->
                            <form action="<?php echo e(route('appointments.shift.process')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="appointment_id" value="<?php echo e($appointment->id); ?>">

                                <select name="new_schedule_id" class="p-2 border border-gray-300 rounded">
                                    <option value="" disabled selected>Select New Schedule</option>
                                    <?php $__currentLoopData = $availableSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($schedule->id); ?>">
                                            <?php echo e($schedule->date); ?> - <?php echo e($schedule->start_time); ?> to <?php echo e($schedule->end_time); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <button type="submit" class="ml-2 p-2 bg-blue-500 text-white rounded">Shift</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\My comany\dr-yohannes online schedule\dr-john\resources\views\scheduler\schedules\shift.blade.php ENDPATH**/ ?>